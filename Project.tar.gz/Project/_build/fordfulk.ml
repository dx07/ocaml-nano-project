open Graph

let find_path graph s t =
	let rec call_next graph s t path exp liste = match liste with
		| [] -> []
		| (e,x)::l ->
				let res = f_p graph x t ((e,x)::path) exp in
				if res = [] then
					call_next graph s t path exp l
				else
					res
	and f_p graph s t path exp =
		if s = t 
		then 
			path
		else
			let cur = find_vertex graph s in
			let next_list = List.filter (fun (_,x)->not(List.mem x exp)) cur.outedges in
				match next_list with
				| [] -> []
				| liste ->
					call_next graph s t path ((cur.id)::exp) next_list
	in List.rev (f_p graph s t [] []);;


let get_flow graph path = 
	let rec g_f graph path flow = match path with
		| [] -> flow
		| (e,_) :: rest -> if (e < flow)
					then g_f graph (rest) e
					else g_f graph (rest) flow
	in g_f graph path max_int;;


let update_graph graph path flow origin=  
	let rec u_g graph path flow origin= match path with
		| [] -> graph
		| (e,s) :: rest ->
          begin
					  let new_flow = (e - flow) in
						  if
							  new_flow < 0
						  then
							  assert false
						  else
                begin
							    if new_flow = 0 then
								    del_edge graph origin s
                  else
                    match (find_edge graph origin s) with
							      |None -> assert false
                    |Some a -> add_edge graph origin s new_flow
                end;
                match (find_edge graph s origin) with
							      |None -> add_edge graph s origin flow
                    |Some a -> add_edge graph s origin (flow+a)
						end;
					 u_g graph rest flow s
	in u_g graph path flow origin;;


let get_max_flow graph s t convert reconv=
	let rec g_m_f graph s t path = match path with
		| [] -> graph
		| a_path -> let n_g = (update_graph graph a_path (get_flow graph a_path) s)
    in g_m_f n_g s t (find_path n_g s t)
	
	in let n_g = convert graph
	in reconv(g_m_f n_g s t (find_path n_g s t));;


let get_max_flow_rendu graph flow_graph convert= 
  let s_graph = convert graph 
  and s_flow_graph = convert flow_graph
  in Hashtbl.iter (fun key v-> List.iter (fun (e,id) ->add_edge s_graph v.id id (
  Printf.sprintf "%s/%s" (string_of_int ((int_of_string e)-
  match(find_edge s_flow_graph v.id id) with
    |None -> 0
    |Some a -> int_of_string a
  )) e)) v.outedges) s_graph.vertices;
  s_graph;;









