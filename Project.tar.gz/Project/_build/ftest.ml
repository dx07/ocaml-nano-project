open Graph

let () =

  if Array.length Sys.argv <> 5 then
    begin
      Printf.printf "\nUsage: %s infile source sink outfile\n\n%!" Sys.argv.(0) ;
      exit 0
    end ;

  let infile = Sys.argv.(1)
  and _source = Sys.argv.(2)
  and _sink = Sys.argv.(3)
  and outfile = Sys.argv.(4) in

  let graph = Gfile.from_file infile in

    (* Rewrite the graph that has been read. *)
    (*let () = Gfile.write_file outfile graph *)

    (* Rewrite the graph in dot language. *)
    (*let () = Gfile.export outfile graph*)

    (* Write the max flow graph in dot language. *)
    (*let () = Gfile.export outfile
      (Fordfulk.get_max_flow graph _source _sink int_of_string_ford string_of_int_ford ) *)

    (* Write the max flow graph with capacity in dot language. *)
    let () = 
    let flow_graph = Fordfulk.get_max_flow graph _source _sink int_of_string_ford string_of_int_ford
    in Gfile.export outfile
      (Fordfulk.get_max_flow_rendu graph flow_graph (fun x-> x) ) 


    in ()
